# FocusGuard

Instagram distraction blocker using Android AccessibilityService.

## Current behavior
- Home feed posts/Reels are hidden below Stories.
- Stories area is tap-only: taps are replayed to Instagram, while horizontal/vertical swipes are consumed.
- Search/Explore is fully covered with a motivational quote; it does not redirect Home.
- Reels page is fully covered with a motivational quote; it does not redirect Home.
- Profile lower content is covered regardless of entry route, including Highlights, Posts, Reels and Tagged content.
- A Reel opened directly from a Direct message can be viewed, but swipes are blocked so the user cannot continue into the Reel feed.
- A directly shared post/Reel remains accessible from Direct messages.
- Light/dark mode follows Android UI mode; power-saver mode uses the dark palette.
- Accessibility events are coalesced with a short delay for fast response.

## Build
The GitHub Actions workflow is `.github/workflows/build-apk.yml` and builds `:app:assembleDebug`.
