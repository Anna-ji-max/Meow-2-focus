package com.example.focusguard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

private const val IG = "com.instagram.android"
private val TAB_BAR_IDS = listOf("tab_bar", "bottom_tab_bar")
private val HOME_TAB_IDS = listOf("feed_tab", "home_tab")
private val SEARCH_TAB_IDS = listOf("search_tab", "search_tab_button")
private val REELS_TAB_IDS = listOf("clips_tab", "reels_tab")
private val DIRECT_TAB_IDS = listOf("direct_tab", "direct_tab_button", "action_bar_inbox", "inbox_tab", "messenger_tab")
private val SEARCH_BOX_IDS = listOf("action_bar_search_edit_text", "search_edit_text")
private val REEL_PLAYER_IDS = listOf("reel_recycler", "reel_player_page_container", "clips_view_pager", "reel_viewer_root")

private val DARK_BG = 0xFF0C0F14.toInt()
private val LIGHT_BG = 0xFFFFFFFF.toInt()

data class Colors(val bg: Int, val text: Int, val sub: Int, val accent: Int)

object Palette {
    private val LIGHT = Colors(LIGHT_BG, 0xFF262626.toInt(), 0xFF737373.toInt(), 0xFF0095F6.toInt())
    private val DARK = Colors(DARK_BG, 0xFFFAFAFA.toInt(), 0xFFA8A8A8.toInt(), 0xFF0095F6.toInt())
    fun now(c: Context): Colors {
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val saver = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        return if (night || saver) DARK else LIGHT
    }
}

object Quotes {
    val full = listOf(
        "You came here for a reason. Go do that.",
        "Your time is the one thing you can't scroll back.",
        "Be where your feet are.",
        "Close the feed. Open your day.",
        "Nothing here is as good as what you're about to do."
    )
    val tile = listOf("Focus", "Be here", "Not now", "Breathe")
}

class GuardService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val views = HashMap<String, View>()
    private val rects = HashMap<String, Rect>()
    private var pending = false
    private var lastDirectAt = 0L
    private var sharedViewer = false

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ui.post { evaluate() }
        ui.postDelayed({ evaluate() }, 80)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.packageName != IG) return
        if (!pending) {
            pending = true
            val delay = if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) 0L else 8L
            ui.postDelayed({ pending = false; evaluate() }, delay)
        }
    }

    override fun onInterrupt() = hideAll()
    override fun onDestroy() { hideAll(); super.onDestroy() }

    private fun evaluate() {
        if (!::wm.isInitialized) return
        val root = rootInActiveWindow
        if (root == null || root.packageName != IG) { hideAll(); return }

        val rawScreen = bounds(root)
        val screen = safeScreen(rawScreen)
        val bar = first(root, TAB_BAR_IDS)
        val homeSelected = isSelected(root, HOME_TAB_IDS)
        val search = isSelected(root, SEARCH_TAB_IDS) || first(root, SEARCH_BOX_IDS)?.isFocused == true
        val reels = isSelected(root, REELS_TAB_IDS)
        val direct = isDirectScreen(root)
        val profile = isProfile(root)
        val reelOpen = !profile && REEL_PLAYER_IDS.any { find(root, it) != null }
        val home = homeSelected || (!search && !reels && !direct && looksLikeHome(root, rawScreen))
        val now = System.currentTimeMillis()

        if (direct) {
            lastDirectAt = now
            sharedViewer = false
        } else if (!home && !search && !reels && !profile && now - lastDirectAt < 6000L) {
            sharedViewer = true
        } else if (profile || home || search || reels || now - lastDirectAt >= 2500L) {
            sharedViewer = false
        }

        if (search) {
            hide("feed"); hide("stories"); hide("profile"); hide("sharedGesture")
            show("full", screen, Quotes.full.random(), 22f)
            return
        }

        if (reels || (reelOpen && !sharedViewer)) {
            hide("feed"); hide("stories"); hide("profile"); hide("sharedGesture")
            show("full", screen, Quotes.full.random(), 22f)
            return
        }

        if (sharedViewer) {
            hide("full"); hide("feed"); hide("stories"); hide("profile")
            showGesture("sharedGesture", screen, horizontalAllowed = false)
            return
        }

        hide("sharedGesture"); hide("full")

        if (home) {
            val storyBottom = findStoryBottom(root, rawScreen) ?: (rawScreen.top + (rawScreen.height() * 0.235f).toInt())
            val feedBottom = bar?.let { bounds(it).top } ?: safeScreen(rawScreen).bottom
            if (feedBottom > storyBottom + dp(20)) {
                // Stories: taps + horizontal story navigation are allowed; vertical swipes are blocked.
                showGesture("stories", Rect(rawScreen.left, rawScreen.top + dp(55), rawScreen.right, storyBottom), horizontalAllowed = true)
                showBlank("feed", Rect(rawScreen.left, storyBottom, rawScreen.right, feedBottom))
            }
        } else {
            hide("stories"); hide("feed")
        }

        if (profile) {
            val top = profileContentTop(root, rawScreen)
            val bottom = safeScreen(rawScreen).bottom
            if (top < bottom - dp(20)) showBlank("profile", Rect(rawScreen.left, top, rawScreen.right, bottom))
        } else hide("profile")

        val reelsTab = first(root, REELS_TAB_IDS)
        if (reelsTab != null && !reels) show("tile", bounds(reelsTab), Quotes.tile.random(), 9f) else hide("tile")
    }

    private fun isProfile(root: AccessibilityNodeInfo): Boolean {
        if (containsText(root, listOf("Followers", "Following")) &&
            (containsText(root, listOf("Follow", "Following", "Message", "Edit profile", "Posts")))) return true
        val desc = allVisibleText(root)
        return desc.contains("followers", true) && desc.contains("following", true)
    }

    private fun profileContentTop(root: AccessibilityNodeInfo, screen: Rect): Int {
        val tabRects = mutableListOf<Rect>()
        collectTextRects(root, listOf("Posts", "Reels", "Tagged", "Tagged posts"), tabRects)
        val tabTop = tabRects.filter { it.top > screen.top + dp(100) }.minByOrNull { it.top }?.top

        // Prefer the bottom of the actual profile header controls. This avoids covering
        // the avatar/name/bio while still covering Highlights and everything below it.
        val headerControls = mutableListOf<Rect>()
        collectTextRects(root, listOf("Edit profile", "Message", "Follow", "Following"), headerControls)
        val headerBottom = headerControls.maxByOrNull { it.bottom }?.bottom

        return when {
            headerBottom != null && tabTop != null -> minOf(tabTop - dp(8), headerBottom + dp(24))
            tabTop != null -> tabTop - dp(8)
            headerBottom != null -> headerBottom + dp(24)
            else -> screen.top + (screen.height() * 0.48f).toInt()
        }
    }

    private fun findStoryBottom(root: AccessibilityNodeInfo, screen: Rect): Int? {
        val names = listOf("reel_tray_container", "stories_tray", "story_tray", "row_feed_story")
        return names.asSequence().mapNotNull { find(root, it) }.map { bounds(it) }
            .filter { it.width() > screen.width() * .55 && it.top < screen.height() * .45 }
            .maxByOrNull { it.bottom }?.bottom
    }

    private fun looksLikeHome(root: AccessibilityNodeInfo, screen: Rect): Boolean {
        return findStoryBottom(root, screen) != null && first(root, REELS_TAB_IDS) != null
    }

    private fun showGesture(key: String, r: Rect, horizontalAllowed: Boolean) {
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val v = GestureGate(this, horizontalAllowed)
                wm.addView(v, params(r)); views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private inner class GestureGate(context: Context, private val horizontalAllowed: Boolean) : View(context) {
        private var downX = 0f
        private var downY = 0f
        private var moved = false
        private val threshold = dp(10)

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; moved = false; return true }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.rawX - downX) > threshold || abs(ev.rawY - downY) > threshold) moved = true
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!moved) replayTap(ev.rawX, ev.rawY)
                    else if (horizontalAllowed && abs(dx) > abs(dy) && abs(dx) > threshold) replaySwipe(downX, downY, ev.rawX, ev.rawY)
                    return true
                }
                MotionEvent.ACTION_CANCEL -> return true
            }
            return true
        }
    }

    private fun replayTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build(), null, null)
    }

    private fun replaySwipe(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 180)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    private fun containsText(node: AccessibilityNodeInfo?, values: List<String>): Boolean {
        if (node == null || !node.isVisibleToUser) return false
        val hay = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ")
        if (values.any { hay.contains(it, true) }) return true
        for (i in 0 until node.childCount) if (containsText(node.getChild(i), values)) return true
        return false
    }

    private fun allVisibleText(node: AccessibilityNodeInfo?): String {
        if (node == null || !node.isVisibleToUser) return ""
        val sb = StringBuilder()
        node.text?.let { sb.append(it).append(' ') }
        node.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until node.childCount) sb.append(allVisibleText(node.getChild(i)))
        return sb.toString()
    }

    private fun collectTextRects(node: AccessibilityNodeInfo?, labels: List<String>, out: MutableList<Rect>) {
        if (node == null || !node.isVisibleToUser) return
        val t = listOfNotNull(node.text?.toString(), node.contentDescription?.toString()).joinToString(" ")
        if (labels.any { t.equals(it, true) || t.contains(it, true) }) out.add(bounds(node))
        for (i in 0 until node.childCount) collectTextRects(node.getChild(i), labels, out)
    }

    private fun isDirectScreen(root: AccessibilityNodeInfo): Boolean =
        isSelected(root, DIRECT_TAB_IDS)

    private fun isSelected(root: AccessibilityNodeInfo, ids: List<String>): Boolean = ids.asSequence().mapNotNull { find(root, it) }.any { it.isSelected }
    private fun first(root: AccessibilityNodeInfo, ids: List<String>): AccessibilityNodeInfo? = ids.asSequence().mapNotNull { find(root, it) }.firstOrNull()
    private fun find(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByViewId("$IG:id/$name").firstOrNull { it.isVisibleToUser }
    private fun bounds(n: AccessibilityNodeInfo) = Rect().also { n.getBoundsInScreen(it) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun safeScreen(r: Rect): Rect {
        val nav = resources.getIdentifier("navigation_bar_height", "dimen", "android").let { if (it != 0) resources.getDimensionPixelSize(it) else dp(24) }
        return Rect(r.left, r.top, r.right, (r.bottom - nav).coerceAtLeast(r.top + dp(200)))
    }

    private fun show(key: String, r: Rect, msg: String, sp: Float) {
        try {
            val existing = views[key]
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val v = build(msg, sp); wm.addView(v, params(r)); views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun showBlank(key: String, r: Rect) {
        try {
            val existing = views[key]
            if (existing != null) { if (rects[key] != r) wm.updateViewLayout(existing, params(r)) }
            else { val v = buildBlank(); wm.addView(v, params(r)); views[key] = v }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun buildBlank(): View = View(this).apply {
        setBackgroundColor(Palette.now(context).bg)
        isClickable = true
        setOnTouchListener { _, _ -> true }
    }

    private fun build(msg: String, sp: Float): View {
        val c = Palette.now(this)
        val pad = dp(if (sp > 12f) 32 else 2)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(c.bg)
            setPadding(pad, 0, pad, 0)
            isClickable = true
            setOnTouchListener { _, _ -> true }
            addView(TextView(context).apply { text = msg; textSize = sp; gravity = Gravity.CENTER; setTextColor(c.text) })
        }
    }

    private fun hide(key: String) { rects.remove(key); views.remove(key)?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
    private fun hideAll() = views.keys.toList().forEach { hide(it) }

    private fun params(r: Rect) = WindowManager.LayoutParams(
        r.width(), r.height(), WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = r.left; y = r.top }
}
